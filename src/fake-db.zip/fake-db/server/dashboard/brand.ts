export const brands = [
  {
    id: 1,
    featured: true,
    name: "Samsung",
    logo: "/assets/images/brands/samsung.png",
  },
  {
    id: 2,
    featured: false,
    name: "Brokeshire’s",
    logo: "/assets/images/brands/brokshire.png",
  },
  {
    id: 3,
    featured: true,
    name: "Levis",
    logo: "/assets/images/brands/levis.png",
  },
  {
    id: 4,
    featured: false,
    name: "Raymond",
    logo: "/assets/images/brands/raymond.png",
  },
  {
    id: 5,
    featured: true,
    name: "Apple",
    logo: "/assets/images/brands/apple-2.png",
  },
  {
    id: 6,
    featured: false,
    name: "Amazon",
    logo: "/assets/images/brands/amazon.png",
  },
  {
    id: 7,
    featured: true,
    name: "AliBaba",
    logo: "/assets/images/brands/alibaba.png",
  },
  {
    id: 8,
    featured: true,
    name: "ebay",
    logo: "/assets/images/brands/ebay.png",
  },
];
