import ShopLayout1 from 'components/layouts/ShopLayout1';
import React from 'react';

const AboutPage: React.FC = () => {
  return (
    <ShopLayout1>
      <div>about</div>
    </ShopLayout1>
  );
};

export default AboutPage;
