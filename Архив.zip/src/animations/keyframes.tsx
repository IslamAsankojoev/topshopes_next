import { keyframes } from "@mui/styled-engine";

export const slideDown = keyframes`
    from {transform: translateY(-200%)}
    to {transform: translateY(0)}
`;
