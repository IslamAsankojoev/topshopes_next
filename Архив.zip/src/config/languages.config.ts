export const languages = ['ru', 'kg', 'tr', 'en', 'pl'];
