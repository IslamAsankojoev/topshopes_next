export const text = {
  en: {
    title: '50% Off For Your First Shopping',
  },
  ru: {
    title: '50% Скидка на первую покупку',
  },
  kg: {
    title: '50% Скидка биринчи сатып алуу',
  },
  tr: {
    title: 'İlk Alışverişiniz İçin %50 İndirim',
  },
  pl: {
    title: '50% Zniżki na pierwszą zakup',
  },
};
