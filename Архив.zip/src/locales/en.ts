export const text = {
  title: '50% Discount on first purchase',
  description: 'Get 50% discount on first purchase when you sign up to our newsletter',
};
