export const text = {
  title: '50% zniżki na pierwszą zakup',
  description: 'Otrzymaj 50% zniżki na pierwszą zakup, gdy się zapiszesz do naszego biuletynu',
};
