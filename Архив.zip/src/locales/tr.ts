export const text = {
  title: '50% İndirim İlk Alışverişte',
  description: 'Bültenimize kayıt olduğunuzda ilk alışverişiniz için %50 indirim kazanın',
};
