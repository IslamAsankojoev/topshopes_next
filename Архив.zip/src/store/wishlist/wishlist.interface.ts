import { IProduct } from 'shared/types/product.types';

export interface IInitialState {
  items: IProduct[];
}
